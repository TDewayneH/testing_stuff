#!/usr/bin/env python3

"""
    I've been focusing on the wrong type of programming appreantly...
"""

import sys, decimal
from pathlib import Path

newList = []
nList = []
neList = []
lenght = 0
def main():
    textFile = Path('textFile.txt')#sys.argv[1]
    with open(textFile) as f:
        for i in f:
            newList.append(i)
        for i in newList:
            nList.append(i.split('\n')[0])
        for i in nList:
            neList.extend(i.split())
        lenght = len(neList)
        for index, item in enumerate(neList):
            if(index < (lenght - 1)):
                if(index%2 != 0):
                    if(index%2 == 0):
                        num1 = neList[index]
                    else:
                        num1 = neList[index+1]
                    if((index+1)%2 != 0):
                        num2 = neList[index+1]
                    else:
                        num2 = neList[index+2]
                else:
                    index+1
                    num1 = neList[index]
                    num2 = neList[index+1]
                    evenlyDiv(num1,num2)
                    


def evenlyDiv(n, n2):
    n = round(float(n))
    n2 = round(float(n2))
    for num in range(n,n2+1):
        if(n <= 0):
            rem = decimal.Decimal(num)/decimal.Decimal(n)
            if(str(float(rem))[-1]=='0'):
                print(num)

            #if(round(decimal.Decimal(num)%decimal.Decimal(n)==0)):
             #   print(num)
            #if(num % (nN % -nN2) == 0):
             #   print(num)
        else:
            #print(num)
            #if(round(decimal.Decimal(num)%(decimal.Decimal(n) %\
                   #                        decimal.Decimal(n2)))== 2):
            rem = decimal.Decimal(num)/decimal.Decimal(n)
            if(round(float(rem))==0):
                print(num)
            #if(str(float(rem))[-1]=='0'):
             #   print(num)


            
            #if(decimal.Decimal(num)/decimal.Decimal(n)==0):
                #print(num)
            #if(num % (nN % nN2) == 0):
                #print(num)
    print("")
main()
