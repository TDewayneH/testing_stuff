#!/usr/bin/env python3

"""
    I've been focusing on the wrong type of programming appreantly...
"""

import sys, decimal
from pathlib import Path

newList = []
nList = []
neList = []
lenght = 0
def main():
    textFile = Path('textFile.txt')#sys.argv[1]
    with open(textFile) as f:
        for i in f:
            newList.append(i)
        for i in newList:
            nList.append(i.split('\n')[0])
        for i in nList:
            neList.extend(i.split())
        lenght = len(neList)
        for index, item in enumerate(neList):
            if(index < (lenght - 1)):
                if(index%2 != 0):
                    if(index%2 == 0):
                        num1 = neList[index]
                    else:
                        num1 = neList[index+1]
                    if((index+1)%2 != 0):
                        num2 = neList[index+1]
                    else:
                        num2 = neList[index+2]
                else:
                    index+1
                    num1 = neList[index]
                    num2 = neList[index+1]
                    lis = frange(num1,num2,1)
                    #print(list(lis))
                    evenlyDiv(lis,num1,num2)
                    


def evenlyDiv(l, n, n2):
    for num in l:
        #print(num)
        if(n[0] == '-'):
            rem = round(decimal.Decimal(num))/round(decimal.Decimal(n))
            if(str(float(rem))[-1]=='0'):
                print(round(num))
        else:
            if(round(decimal.Decimal(n))%2==0):
                rem = decimal.Decimal(n)/decimal.Decimal(num)
                print(round(rem))
                #if(str(float(round(rem)))[-1]=='0'):
                #    print(int(num))
            else:
                rem = round(decimal.Decimal(num))/round(decimal.Decimal(n))
                if(str(float(rem))[-1]=='0'):
                    print(int(num))

                
                """
                rem = round(decimal.Decimal(n))/decimal.Decimal(num)
                rem2 = str(float(rem))[-1]
                #print(float(rem))
                if(decimal.Decimal(rem2)%3 == 0):
                    print(int(num))
                """
    print("")

def frange(start, end, inc):
    i = float(start)
    end = float(end)+1
    inc = float(inc)
    while i < end:
        yield i
        i = float(i) + inc
    
main()
