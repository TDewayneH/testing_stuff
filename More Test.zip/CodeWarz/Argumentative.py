#!/usr/bin/env python3
import sys
print(' '.join(sys.argv[1:]))
