#!/usr/bin/env python3
import sys
from pathlib import Path

fGroup = 0
sGroup = 0
tGroup = 0
frGroup = 0
fiGroup = 0
siGroup = 0
seGroup = 0
eGroup = 0
nGroup = 0
tnGroup = 0

outPut = []

textFile = Path("textFile.txt")
#sys.argv[1]
with open(textFile) as f:
    for n in f:
        if int(n) <= 9:
            fGroup += 1
        elif int(n) <= 19:
            sGroup += 1
        elif int(n) <= 29:
            tGroup += 1
        elif int(n) <= 39:
            frGroup += 1
        elif int(n) <= 49:
            fiGroup += 1
        elif int(n) <= 59:
            siGroup += 1
        elif int(n) <= 69:
            seGroup += 1
        elif int(n) <= 79:
            eGroup += 1
        elif int(n) <= 89:
            nGroup += 1
        else:
            tnGroup += 1
    print(fGroup,sGroup,tGroup,frGroup,fiGroup,\
          siGroup,seGroup,eGroup,nGroup,tnGroup)
f.close()
