#!/usr/bin/env python3
from pathlib import Path
running = True
while running:
    textFile = input("Please enter the path: ")
    textFile = Path(textFile)
    if(textFile.exists()):
        with open(textFile) as f:
            for line in f:
                print(line, end='')
        f.close()
        running = False
    else:
        print("Wrong path please enter the correct path to the file.")
        
