#!/usr/bin/env python3
import sys
from pathlib import Path


def main():
    textFile = sys.argv[1]
    maxTotal = 0
    numbers=[]
    totalNum = []
    grouped = []
    count = 0
    countedList = []
    with open(textFile) as f:
        for i in f:
            numbers.append(int(i))
        numbers = sorted(numbers)
        maxTotal = max(numbers)
    with open(textFile) as f:
        for i in range(0,int(maxTotal)+1):
            totalNum.append(i)
        
        grouped = list(group(totalNum))
        for k in grouped:
            for i in numbers:
                if(k>=i):
                    if(roundNum(i) <= i):
                        if(k>=roundNum(i) and k<=roundNum(i)+10):
                            count+= 1
                        else:
                            count = 0
                    else:
                        if(k>=roundNum(i)-10 and k<=roundNum(i)):
                           count+= 1
                        else:
                            count = 0
                    
            countedList.append(count)
            count = 0
        string = ''.join(str(e) for e in countedList)
        print(string)
    f.close()

def group(L):
    first = last = L[0]
    for n in L[1:]:
        if not str(n).endswith("0"):
            last = n
        else:
            #yield first, last
            yield last
            first = last = n
    #yield first, last
    yield last

def roundNum(n):
    rem = n % 10
    if rem < 5:
        n = int(n/10)*10
    else:
        n = int((n+9)//10*10)
    return n

main()


        
        
    
