#!/usr/bin/env python3
import sys
textFile = sys.argv[1]
with open(textFile) as f:
    for line in f:
        print(line, end='')
f.close()
        
